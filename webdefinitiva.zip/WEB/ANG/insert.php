<?php
/* Conectar-se al servidor */
$link = mysqli_connect("localhost", "root", "alumnes", "cryptostudios");

//Comprovar conexió
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


// Escape user imputs
$nom = mysqli_real_escape_string($link, $_REQUEST['nom']);
$mail = mysqli_real_escape_string($link, $_REQUEST['mail']);
$passw = mysqli_real_escape_string($link, $_REQUEST['passw']);


// Insert query
$sql = "INSERT INTO login (nom, mail, passw) VALUES ('$nom', '$mail', '$passw')";
if (mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Tencar conexió
mysqli_close($link);
?>