<!DOCTYPE html> 
<html>
<head>
    <meta charset=UTF-8>
    <title>CryptoStudios | Register</title>
    <link rel="stylesheet" href="../ColorMode/DarkLog.css">
</head>
<header>
    <div>
        <a href="../indexANG.html" class="nav">← Back</a>
    </div>
</header>
<body style="background-color: #131b24;">
    <center>
    <div style="height: 100px;"></div>
    <div class="logdiv">
        <h1>Register</h1>
    <div style="height: 50px;"></div>
    
        <form action="insert.php" method="post">
            <div class="logpack"> 
                <input type="text" id="fname" name="nom" value="" class="text" placeholder="User name" required><br>
            </div>
            <div class="logpack">
                <input type="text" id="mail" name="mail" value="" class="text" placeholder="Mail Address" required><br>
            </div>
            <div class="logpack">
                <input type="password" id="passw" name="pass" value="" class="text" placeholder="Password" required><br>
            </div>

            <div style="height: 50px;"></div>
            <input type="submit" value="SEND" class="envia">
          </form> 

    <div style="height: 50px;"></div> 

    <div class="links">
        <a href="login.html" class="linksText">You already have a user?</a>
        <div style="height: 50px;"></div> 

    </div>

    </div>
    </center>


<footer>
    <center><p>© 2020 CryptoStudios</p></center>
</footer>
</body>
</html>