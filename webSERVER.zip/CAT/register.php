<!DOCTYPE html> 
<html>
<head>
    <meta charset=UTF-8>
    <title>CryptoStudios | Registre</title>
    <link rel="stylesheet" href="../ColorMode/DarkLog.css">
</head>
<header>
    <div>
        <a href="../index.html" class="nav">← Enrere</a>
    </div>
</header>
<body style="background-color: #131b24;">
    <center>
    <div style="height: 100px;"></div>
    <div class="logdiv">
        <h1>Registra't</h1>
    <div style="height: 50px;"></div>
    
        <form action="insert.php" method="post">
            <div class="logpack"> 
                <input type="text" id="fname" name="nom" value="" class="text" placeholder="Nom d'usuari" required><br>
            </div>
            <div class="logpack">
                <input type="text" id="mail" name="mail" value="" class="text" placeholder="Correu Electrònic" required><br>
            </div>
            <div class="logpack">
                <input type="password" id="passw" name="pass" value="" class="text" placeholder="Contrassenya" required><br>
            </div>

            <div style="height: 50px;"></div>
            <input type="submit" value="Envia" class="envia">
          </form> 

    <div style="height: 50px;"></div> 

    <div class="links">
        <a href="login.html" class="linksText">Ja tens un usuari?</a>
        <div style="height: 50px;"></div> 

    </div>

    </div>
    </center>


<footer>
    <center><p>© 2020 CryptoStudios</p></center>
</footer>
</body>
</html>